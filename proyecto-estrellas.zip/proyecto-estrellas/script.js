const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d", { alpha: true });
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;
ctx.imageSmoothingEnabled = false; // PIXEL-ART NÍTIDO

// Estrellas estáticas
const stars = Array.from({ length: 140 }, () => ({
  x: Math.random() * canvas.width,
  y: Math.random() * canvas.height,
  r: Math.random() * 1.5 + 0.5,
  a: Math.random() * 0.8 + 0.2
}));

// Sprites
const parejaImg = new Image(); parejaImg.src = "assets/pareja.png";
const perro1 = new Image(); perro1.src = "assets/perro1.png";
const perro2 = new Image(); perro2.src = "assets/perro2.png";
const estrellaImg = new Image(); estrellaImg.src = "assets/estrella.png";

// Estrella fugaz
const shootingStar = {
  x: canvas.width + 100,
  y: Math.random() * canvas.height / 2,
  speed: 10,
  active: false,
  trail: []
};

// Alternancia de frames del perro
let perroFrame = 0;
let lastSwitch = performance.now();

// Escucha resize
window.addEventListener("resize", () => {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
  ctx.imageSmoothingEnabled = false;
});

function drawStars(time) {
  stars.forEach(s => {
    ctx.globalAlpha = s.a * (0.6 + 0.4 * Math.sin(time/1000 + s.x));
    ctx.fillStyle = "white";
    ctx.beginPath();
    ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
    ctx.fill();
  });
  ctx.globalAlpha = 1;
}

function drawPareja() {
  const w = 150, h = 150;
  ctx.drawImage(parejaImg, 0, 0, parejaImg.width, parejaImg.height,
                canvas.width / 2 - w / 2, canvas.height - h - 30, w, h);
}

function drawPerro(time) {
  if (time - lastSwitch > 600) {
    perroFrame = (perroFrame + 1) % 2;
    lastSwitch = time;
  }
  const img = perroFrame === 0 ? perro1 : perro2;
  ctx.drawImage(img, 0, 0, img.width, img.height,
                canvas.width / 2 - 20, canvas.height - 160, 40, 40);
}

function drawShootingStar(time) {
  if (shootingStar.active) {
    // trail
    shootingStar.trail.push({x: shootingStar.x, y: shootingStar.y});
    if (shootingStar.trail.length > 12) shootingStar.trail.shift();

    // draw trail
    for (let i = 0; i < shootingStar.trail.length; i++) {
      const p = shootingStar.trail[i];
      ctx.globalAlpha = i / shootingStar.trail.length * 0.6;
      ctx.drawImage(estrellaImg, p.x, p.y, 50, 25);
    }
    ctx.globalAlpha = 1;

    // draw head
    ctx.drawImage(estrellaImg, shootingStar.x, shootingStar.y, 50, 25);
    shootingStar.x -= shootingStar.speed;
    shootingStar.y += shootingStar.speed * 0.2;
    if (shootingStar.x < -60) {
      shootingStar.active = false;
      shootingStar.x = canvas.width + 100;
      shootingStar.y = Math.random() * canvas.height / 3;
      shootingStar.trail = [];
    }
  } else if (Math.random() < 0.004) {
    shootingStar.active = true;
  }
}

function loop(time) {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  // ligero gradiente vertical
  const g = ctx.createLinearGradient(0,0,0,canvas.height);
  g.addColorStop(0, "#02030a");
  g.addColorStop(1, "#000000");
  ctx.fillStyle = g;
  ctx.fillRect(0,0,canvas.width,canvas.height);

  drawStars(time);
  drawShootingStar(time);
  drawPareja();
  drawPerro(time);
  requestAnimationFrame(loop);
}

Promise.all([
  new Promise(r => parejaImg.onload = r),
  new Promise(r => perro1.onload = r),
  new Promise(r => perro2.onload = r),
  new Promise(r => estrellaImg.onload = r),
]).then(() => {
  requestAnimationFrame(loop);
});
