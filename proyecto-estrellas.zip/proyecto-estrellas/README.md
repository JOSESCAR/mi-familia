# Noche Estrellada Animada

Este proyecto muestra una pareja contemplando el cielo estrellado, un perrito entre ellos y una estrella fugaz animada — todo en **pixel art**.

## Cómo funciona
- Fondo con estrellas tintineantes y estrella fugaz aleatoria con rastro.
- Perrito animado con dos frames (izquierda / derecha).
- Integración de una playlist de Spotify embebida.

## Uso
1. Sube todo este repositorio a GitHub.
2. (Opcional) Cambia el `playlist_id` en `index.html` por el tuyo.
3. Activa GitHub Pages (Branch: `main`, carpeta `/root`) y listo.

## Créditos
Sprites de pixel art generados por script (Pillow). Libre de uso.
